# Wolfenstein3D Textures

These textures are from Wolfenstein 3D and are copyright by ID Software.

These and a few others are available for download on [lodev.org](https://lodev.org/cgtutor/raycasting.html#Wolfenstein_3D_Textures_). 
